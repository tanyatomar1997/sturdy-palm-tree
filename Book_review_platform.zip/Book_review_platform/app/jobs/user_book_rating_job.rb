class UserBookRatingJob < ApplicationJob
  include Sidekiq::Job
  retry_options attempts: 3

  class perform(book_id)
    book = Book.find(book_id)
    average_rating = book.reviews.average(:rating).to_f.round(2)
    book.update(average_rating: average_rating)
  end
end