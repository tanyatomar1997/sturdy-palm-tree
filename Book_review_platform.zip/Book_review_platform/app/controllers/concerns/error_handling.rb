module ErrorHandling
  extend ActiveSupport::Concern

  included do
    rescue_from ActiveRecord::RecordNotFound, with: :record_not_found
    rescue_from ActiveRecord::RecordInvalid, with: :record_invalid
    # rescue_from StandardError, with: :handle_standard_error
  end

  ERRORCODES = {
    not_found: 404,
    unprocessable_entity: 422,
    standard_error: 500
  }

  private

  def record_not_found(exception)
    render json: { error: exception.message }, status: :not_found, code: ERRORCODES[:not_found]
  end

  def record_invalid(exception)
    render json: { errors: exception.record.errors.full_messages }, status: :unprocessable_entity, code: ERRORCODES[:unprocessable_entity]  
  end

  def handle_standard_error
    render json: { errors: exception.record.errors.full_messages }, status: :unprocessable_entity, code: ERRORCODES[:standard_error]
  end
end