module Api
  module V1
    class ReviewsController < ApplicationController

      def create
        @book = Book.find(params[:book_id])
        @review = @book.reviews.create!(permit_params)
        @review.save!
        render json: @review
      end

      private

      def permit_params
        params.require(:review).permit(:user_id, :rating, :comment)
      end
    end
  end
end