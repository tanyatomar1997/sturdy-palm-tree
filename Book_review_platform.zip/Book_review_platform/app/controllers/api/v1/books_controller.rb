module Api
  module V1
    class BooksController < ApplicationController
      PERPAGE = 10

      def index
        @books = Book.all.order(created_at: :desc).page(params[:page]).per(params[:per_page] || PERPAGE)
        render json: @books, meta: { current_page: @books.current_page, total_pages: @books.total_pages, total_count: @books.total_count }
      end

      def show
        @book = Book.find(params[:id])
        render json: @book
      end

      def create
        @book = Book.create!(permit_params)
        @book.save!
        render json: @book
      end

      private

      def permit_params
        params.require(:book).permit(:title)
      end
    end
  end
end
