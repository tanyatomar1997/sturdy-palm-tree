class CoverImage < BookImage
  
end