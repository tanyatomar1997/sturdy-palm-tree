class User < ApplicationRecord
    has_many :books
end
