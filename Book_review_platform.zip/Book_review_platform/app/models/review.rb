class Review < ApplicationRecord
  belongs_to :book
  belongs_to :user
  after_create :update_book_average_rating

  def update_book_average_rating
    UserBookRatingJob.perform_async(self.book_id)
  end
end
