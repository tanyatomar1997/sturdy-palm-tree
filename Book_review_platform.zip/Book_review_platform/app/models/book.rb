class Book < ApplicationRecord
  has_many :images, class_name: 'BookImage', dependent: :destroy
  has_many :reviews, dependent: :destroy
end
