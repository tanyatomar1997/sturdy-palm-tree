class AuthorImage < BookImage
  
end