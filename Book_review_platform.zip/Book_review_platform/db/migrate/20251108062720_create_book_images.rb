class CreateBookImages < ActiveRecord::Migration[8.0]
  def change
    create_table :book_images do |t|
      t.timestamps
    end
  end
end
